Simulation of the planet Mercury's orbit around the Sun, using Newtonian gravitation.

Includes Runge-Kutta 4th order integration, because Euler integration doesn't do the job.
